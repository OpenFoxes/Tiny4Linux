This directory contains metadata for the distribution channels through which Tiny4Linux can be obtained.
Currently, only the Arch User Repository (AUR) is supported.
In the future, other options such as Flatpak may also be considered.

The project is distributed in both the GUI and CLI versions.