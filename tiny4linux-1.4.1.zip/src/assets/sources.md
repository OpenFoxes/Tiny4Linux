| Element      | Source                                            | Files                                     |
|--------------|---------------------------------------------------|-------------------------------------------|
| OBSBOT-Logos | https://www.obsbot.com/de/media-kit/obsbot-tiny-2 | obsbot-tiny-2.png, obsbot-tiny-2-side.png |
| Icon         | https://www.flaticon.com/free-icons/lens          | icon.png                                  |